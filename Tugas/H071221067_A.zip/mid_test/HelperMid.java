public class HelperMid {
    public static void showMyData() {
        System.out.println("================");
        System.out.println("DATA DIRI");
        System.out.println("NAMA    : JONATHAN KWAN");
        System.out.println("NIM     : H071221067");
        System.out.println("KELAS   : B");
        System.out.println("PAKET   : A");
        System.out.println("----------------");
    }

    public static void showFeedbackLab() {
        System.out.println("KRITIK DAN SARAN");
        System.out.println("----------------");
        System.out.println("Sebaiknya asisten tidak galak-galak kah batal nanti puasanya");
    }
}
